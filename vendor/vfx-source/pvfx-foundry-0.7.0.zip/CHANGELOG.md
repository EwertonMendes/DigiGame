# Changelog

## 0.7.0 — 2026-09-08

- Add Pawl Snap: 20-frame mechanical engagement, pivot 48,52 and frame-6
  `engage` marker. One-shot at 20 FPS, transparent grid and packed sheets.
- Preserve all 34 earlier assets and canonical pixels: 35 effects, 70 sheets,
  750 canonical frames per layout. Output-only CC0 license remains unchanged.


## 0.6.0 — 2026-09-04

- Added nine Impossible Materials effects: Foldstep, Mercury Molt, Cinder
  Orchid, Suturelight, Hourglass Splinter, Choir Moths, Ferrospine, Rootscript,
  and Prism Loom.
- Six one-shots and three loops add 364 frames; the pack now contains
  34 effects, 68 sprite sheets, and 730 canonical frames per layout.
- Added gameplay markers for blink, metal release, detonation, closure, time
  release, and snare, with ground pivots for rooted effects.
- Preserved all earlier effects and the output-only CC0 license.

## 0.5.0 — 2026-09-01

- Added Focus Charge, a converging pre-fire telegraph for beams, cannons, and
  charged attacks.
- Added Lattice Beam, a seamless sustained-fire loop with a stable body,
  regenerated internal motion, and a rotating source collar.
- Added Beam Cutoff Burst, a terminal stage with rapid retraction, endpoint
  rupture, broken shock rings, and fragment decay.
- Expanded the pack to 25 effects, 50 sprite sheets, and 366 canonical frames.
- Prepared a release-scoped 0.5 GIF containing only the three beam-lifecycle
  additions while preserving every earlier update showcase.

## 0.4.0 — 2026-08-25

- Added Splash Crown, a snapped water-entry one-shot with bilateral sheets,
  concentric ripples, and ballistic droplets.
- Added Shoreline Foam, a seamless wash-and-recede strip for shorelines,
  rivers, and flooded environments.
- Added Dripping Runoff, a seamless guided drip cycle with a catch pool and
  contact ripples.
- Expanded the pack to 22 effects, 44 sprite sheets, and 322 canonical frames.
- Kept the cover stable and prepared a release-scoped 0.4 GIF containing only
  the three water-interaction additions.

## 0.3.0 — 2026-08-20

- Added Rain Field, a seamless diagonal weather loop with near/far depth bands
  and low mist.
- Added Leaf Gust, a lateral autumn-leaf one-shot for wind and movement cues.
- Added Landing Dust, a grounded bilateral burst for landings, dashes, and
  heavy contact.
- Expanded the pack to 19 effects, 38 sprite sheets, and 276 canonical frames.
- Replaced cumulative showcase growth with a roomy, release-scoped update GIF.

## 0.2.0 — 2026-08-16

- Renamed the public collection to PVFX Foundry while retaining the stable
  `pvfx.foundry-thirteen` machine ID for compatibility.
- Added Rift Portal, a seamless dimensional-gate loop.
- Added Venom Ward, a seamless persistent status-aura loop.
- Added Smoke Puff, a compact environmental and gameplay utility one-shot.
- Expanded the pack to 16 effects, 32 sprite sheets, and 232 canonical frames.
- Generalized the release scripts and preview montage for append-only weekly
  expansion.

## 0.1.0 — 2026-08-03

- First public PVFX Foundry release, originally named Foundry Thirteen.
- Added 13 original 96×96, 20 FPS one-shot effects.
- Added fixed five-column grid sheets for simple import.
- Added per-frame trimmed packed sheets with padding and edge extrusion.
- Added exact manifests, pack-level metadata, checksums, and provenance.
- Dedicated the rendered sheets and bundled metadata/documentation to CC0 1.0.
